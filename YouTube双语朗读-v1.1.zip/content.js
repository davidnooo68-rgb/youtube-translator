// YouTube双语朗读插件 - 内容脚本 (无后端版 - 直接调用翻译API)
(function() {
  'use strict';

  let isEnabled = false;
  let lastSubtitle = '';
  let translationPanel = null;
  let currentRate = 1.2;
  let isDragging = false;
  let dragOffset = { x: 0, y: 0 };

  // 配置 - 直接使用公开翻译API
  const CONFIG = {
    minSubtitleLength: 2
  };

  // 创建翻译面板（可拖拽可调整大小）
  function createPanel() {
    if (translationPanel) return;

    translationPanel = document.createElement('div');
    translationPanel.id = 'yt-translator-panel';
    translationPanel.innerHTML = `
      <div class="yt-translator-header" id="yt-translator-drag-handle">
        <span>🎙️ 双语朗读</span>
        <div class="yt-translator-controls-mini">
          <button id="yt-translator-minimize">─</button>
          <button id="yt-translator-close">×</button>
        </div>
      </div>
      <div class="yt-translator-content" id="yt-translator-content">
        <div class="yt-translator-original"></div>
        <div class="yt-translator-translated"></div>
      </div>
      <div class="yt-translator-controls">
        <button id="yt-translator-toggle">⏸️ 暂停</button>
        <div class="yt-translator-rate-wrap">
          <span>语速</span>
          <input type="range" id="yt-translator-rate" min="0.5" max="2" step="0.1" value="1.2">
        </div>
        <button id="yt-translator-resize">⊡</button>
      </div>
    `;

    document.body.appendChild(translationPanel);

    // 绑定事件
    document.getElementById('yt-translator-close').addEventListener('click', stopTranslator);
    document.getElementById('yt-translator-minimize').addEventListener('click', minimizePanel);
    document.getElementById('yt-translator-toggle').addEventListener('click', togglePlayback);
    document.getElementById('yt-translator-resize').addEventListener('click', toggleSize);
    
    const rateInput = document.getElementById('yt-translator-rate');
    rateInput.addEventListener('input', (e) => {
      currentRate = parseFloat(e.target.value);
    });

    // 拖拽功能
    initDrag();
  }

  // 拖拽初始化
  function initDrag() {
    const header = document.getElementById('yt-translator-drag-handle');
    const panel = translationPanel;

    header.addEventListener('mousedown', (e) => {
      if (e.target.tagName === 'BUTTON') return;
      isDragging = true;
      const rect = panel.getBoundingClientRect();
      dragOffset.x = e.clientX - rect.left;
      dragOffset.y = e.clientY - rect.top;
      panel.style.transition = 'none';
    });

    document.addEventListener('mousemove', (e) => {
      if (!isDragging) return;
      panel.style.left = (e.clientX - dragOffset.x) + 'px';
      panel.style.top = (e.clientY - dragOffset.y) + 'px';
      panel.style.right = 'auto';
    });

    document.addEventListener('mouseup', () => {
      isDragging = false;
      if (panel) panel.style.transition = '';
    });
  }

  // 切换大小
  let isLarge = false;
  function toggleSize() {
    isLarge = !isLarge;
    const panel = translationPanel;
    const content = document.getElementById('yt-translator-content');
    
    if (isLarge) {
      panel.style.width = '400px';
      content.style.minHeight = '150px';
    } else {
      panel.style.width = '320px';
      content.style.minHeight = '100px';
    }
  }

  // 最小化
  function minimizePanel() {
    const panel = translationPanel;
    const content = document.getElementById('yt-translator-content');
    const btn = document.getElementById('yt-translator-minimize');
    
    if (panel.classList.contains('minimized')) {
      panel.classList.remove('minimized');
      content.style.display = 'block';
      btn.textContent = '─';
    } else {
      panel.classList.add('minimized');
      content.style.display = 'none';
      btn.textContent = '□';
    }
  }

  // 直接翻译并朗读 - 使用多个免费API
  async function translateAndSpeak(text) {
    if (!text || text.length < CONFIG.minSubtitleLength || text === lastSubtitle) return;
    lastSubtitle = text;

    const originalEl = translationPanel.querySelector('.yt-translator-original');
    const translatedEl = translationPanel.querySelector('.yt-translator-translated');
    
    originalEl.textContent = text;
    translatedEl.textContent = '翻译中...';

    // 立即朗读英文原文
    speakImmediate(text, 'en-US');

    // 翻译
    const translated = await translateText(text);
    
    if (translated && isEnabled) {
      translatedEl.textContent = translated;
      speakImmediate(translated, 'zh-CN');
    }
  }

  // 翻译函数 - 尝试多个免费API
  async function translateText(text) {
    // 方法1: Google翻译 (非官方但免费)
    try {
      const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=zh&dt=t&q=${encodeURIComponent(text)}`;
      const res = await fetch(url);
      const data = await res.json();
      if (data && data[0]) {
        return data[0].map(p => p[0]).join('');
      }
    } catch (e) { console.log('Google翻译失败'); }

    // 方法2: MyMemory (备用)
    try {
      const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=en|zh`;
      const res = await fetch(url);
      const data = await res.json();
      if (data && data.responseData) {
        return data.responseData.translatedText;
      }
    } catch (e) { console.log('MyMemory翻译失败'); }

    return '';
  }

  // 语音朗读
  function speakImmediate(text, lang) {
    if (!text || !isEnabled) return;

    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = lang;
    utterance.rate = currentRate;
    utterance.pitch = 1;

    const voices = window.speechSynthesis.getVoices();
    const voice = voices.find(v => v.lang.includes(lang.split('-')[0]));
    if (voice) utterance.voice = voice;

    window.speechSynthesis.speak(utterance);
  }

  // 开始监听字幕
  function startTranslator() {
    if (isEnabled) return;
    isEnabled = true;
    lastSubtitle = '';

    createPanel();

    const captionWindow = document.querySelector('.ytp-caption-window-container');
    if (!captionWindow) {
      console.log('等待字幕加载...');
      setTimeout(startTranslator, 1000);
      return;
    }

    let lastText = '';
    
    // 定时检查字幕变化
    const checkInterval = setInterval(() => {
      if (!isEnabled) {
        clearInterval(checkInterval);
        return;
      }
      
      const subtitleEl = document.querySelector('.ytp-caption-segment');
      if (subtitleEl) {
        const text = subtitleEl.textContent.trim();
        if (text && text !== lastText) {
          lastText = text;
          translateAndSpeak(text);
        }
      }
    }, 200);

    console.log('🎙️ YouTube双语朗读已启动');
  }

  // 停止
  function stopTranslator() {
    isEnabled = false;
    window.speechSynthesis.cancel();
    if (translationPanel) {
      translationPanel.remove();
      translationPanel = null;
    }
    console.log('🛑 YouTube双语朗读已停止');
  }

  // 切换播放/暂停
  function togglePlayback() {
    isEnabled = !isEnabled;
    const btn = document.getElementById('yt-translator-toggle');
    btn.textContent = isEnabled ? '⏸️ 暂停' : '▶️ 继续';
    if (!isEnabled) {
      window.speechSynthesis.cancel();
    }
  }

  // 监听popup消息
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'start') {
      startTranslator();
      sendResponse({ status: 'started' });
    } else if (request.action === 'stop') {
      stopTranslator();
      sendResponse({ status: 'stopped' });
    } else if (request.action === 'getStatus') {
      sendResponse({ isEnabled });
    }
    return true;
  });

  // 预加载语音
  window.speechSynthesis.getVoices();
  window.speechSynthesis.onvoiceschanged = () => {
    window.speechSynthesis.getVoices();
  };

})();
