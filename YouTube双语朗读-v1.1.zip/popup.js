// popup.js - 插件弹窗控制

document.addEventListener('DOMContentLoaded', async () => {
  const toggleBtn = document.getElementById('toggle-btn');
  const stopBtn = document.getElementById('stop-btn');
  const statusDot = document.getElementById('status-dot');
  const statusText = document.getElementById('status-text');
  const rateInput = document.getElementById('rate');
  const engineSelect = document.getElementById('engine');

  // 获取当前状态
  async function getStatus() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return;

    try {
      const response = await chrome.tabs.sendMessage(tab.id, { action: 'getStatus' });
      updateUI(response.isEnabled);
    } catch (e) {
      // 内容脚本未加载
      updateUI(false);
    }
  }

  // 更新UI状态
  function updateUI(isEnabled) {
    if (isEnabled) {
      statusDot.classList.add('active');
      statusText.textContent = '运行中';
      toggleBtn.classList.add('hidden');
      stopBtn.classList.remove('hidden');
    } else {
      statusDot.classList.remove('active');
      statusText.textContent = '未启动';
      toggleBtn.classList.remove('hidden');
      stopBtn.classList.add('hidden');
    }
  }

  // 开始朗读
  toggleBtn.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) {
      alert('请先打开YouTube视频页面');
      return;
    }

    if (!tab.url.includes('youtube.com')) {
      alert('此插件仅支持YouTube页面');
      return;
    }

    try {
      await chrome.tabs.sendMessage(tab.id, { action: 'start' });
      updateUI(true);
    } catch (e) {
      alert('无法连接到页面，请刷新后重试');
    }
  });

  // 停止朗读
  stopBtn.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return;

    try {
      await chrome.tabs.sendMessage(tab.id, { action: 'stop' });
      updateUI(false);
    } catch (e) {
      console.error('停止失败:', e);
    }
  });

  // 保存设置
  rateInput.addEventListener('change', () => {
    chrome.storage.local.set({ rate: rateInput.value });
  });

  engineSelect.addEventListener('change', () => {
    chrome.storage.local.set({ engine: engineSelect.value });
  });

  // 加载保存的设置
  chrome.storage.local.get(['rate', 'engine'], (result) => {
    if (result.rate) rateInput.value = result.rate;
    if (result.engine) engineSelect.value = result.engine;
  });

  // 初始化
  getStatus();
});
