// 视频双语朗读插件 - 内容脚本 (v1.2 多平台版)
(function() {
  'use strict';

  let isEnabled = false;
  let lastSubtitle = '';
  let translationPanel = null;
  let currentRate = 1.2;
  let isDragging = false;
  let dragOffset = { x: 0, y: 0 };
  let checkInterval = null;

  // 检测当前平台
  const platform = detectPlatform();
  
  function detectPlatform() {
    const host = window.location.hostname;
    if (host.includes('youtube.com')) return 'youtube';
    if (host.includes('bilibili.com')) return 'bilibili';
    if (host.includes('iqiyi.com')) return 'iqiyi';
    if (host.includes('douyin.com')) return 'douyin';
    if (host.includes('zhihu.com')) return 'zhihu';
    return 'unknown';
  }

  // 获取字幕选择器
  function getSubtitleSelector() {
    const selectors = {
      'youtube': '.ytp-caption-segment',
      'bilibili': '.bilibili-player-video-subtitle-text',
      'iqiyi': '.iqiyi-player-subtitle-text',
      'douyin': '.douyin-player-subtitle-text',
      'zhihu': '.VideoSubtitle-text'
    };
    return selectors[platform] || '.subtitle, .caption, [class*="subtitle"], [class*="caption"]';
  }

  // 创建翻译面板
  function createPanel() {
    if (translationPanel) return;

    translationPanel = document.createElement('div');
    translationPanel.id = 'video-translator-panel';
    translationPanel.innerHTML = `
      <div class="vt-header" id="vt-drag-handle">
        <span>🎙️ 双语朗读</span>
        <div class="vt-controls-mini">
          <button id="vt-minimize" title="最小化">─</button>
          <button id="vt-close" title="关闭">×</button>
        </div>
      </div>
      <div class="vt-content" id="vt-content">
        <div class="vt-original"></div>
        <div class="vt-translated"></div>
      </div>
      <div class="vt-controls">
        <button id="vt-toggle" title="暂停/继续">⏸️ 暂停</button>
        <div class="vt-rate-wrap">
          <span>语速</span>
          <input type="range" id="vt-rate" min="0.5" max="2" step="0.1" value="1.2">
        </div>
        <button id="vt-resize" title="调整大小">⊡</button>
      </div>
    `;

    document.body.appendChild(translationPanel);
    bindEvents();
    initDrag();
    
    // 保存位置到localStorage
    const savedPos = localStorage.getItem('vt-panel-position');
    if (savedPos) {
      const pos = JSON.parse(savedPos);
      translationPanel.style.left = pos.x + 'px';
      translationPanel.style.top = pos.y + 'px';
      translationPanel.style.right = 'auto';
    }
  }

  function bindEvents() {
    document.getElementById('vt-close').addEventListener('click', stopTranslator);
    document.getElementById('vt-minimize').addEventListener('click', minimizePanel);
    document.getElementById('vt-toggle').addEventListener('click', togglePlayback);
    document.getElementById('vt-resize').addEventListener('click', toggleSize);
    
    const rateInput = document.getElementById('vt-rate');
    rateInput.addEventListener('input', (e) => {
      currentRate = parseFloat(e.target.value);
    });
  }

  // 拖拽功能
  function initDrag() {
    const header = document.getElementById('vt-drag-handle');
    const panel = translationPanel;

    header.addEventListener('mousedown', (e) => {
      if (e.target.tagName === 'BUTTON') return;
      isDragging = true;
      const rect = panel.getBoundingClientRect();
      dragOffset.x = e.clientX - rect.left;
      dragOffset.y = e.clientY - rect.top;
      panel.style.transition = 'none';
    });

    document.addEventListener('mousemove', (e) => {
      if (!isDragging) return;
      const x = e.clientX - dragOffset.x;
      const y = e.clientY - dragOffset.y;
      panel.style.left = x + 'px';
      panel.style.top = y + 'px';
      panel.style.right = 'auto';
    });

    document.addEventListener('mouseup', () => {
      if (isDragging) {
        isDragging = false;
        panel.style.transition = '';
        // 保存位置
        localStorage.setItem('vt-panel-position', JSON.stringify({
          x: parseInt(panel.style.left),
          y: parseInt(panel.style.top)
        }));
      }
    });
  }

  // 切换大小
  let isLarge = false;
  function toggleSize() {
    isLarge = !isLarge;
    const panel = translationPanel;
    const content = document.getElementById('vt-content');
    
    if (isLarge) {
      panel.style.width = '400px';
      content.style.minHeight = '150px';
    } else {
      panel.style.width = '320px';
      content.style.minHeight = '100px';
    }
  }

  // 最小化
  function minimizePanel() {
    const panel = translationPanel;
    const content = document.getElementById('vt-content');
    const btn = document.getElementById('vt-minimize');
    
    if (panel.classList.contains('minimized')) {
      panel.classList.remove('minimized');
      content.style.display = 'block';
      btn.textContent = '─';
    } else {
      panel.classList.add('minimized');
      content.style.display = 'none';
      btn.textContent = '□';
    }
  }

  // 翻译并朗读
  async function translateAndSpeak(text) {
    if (!text || text.length < 2 || text === lastSubtitle) return;
    lastSubtitle = text;

    const originalEl = translationPanel.querySelector('.vt-original');
    const translatedEl = translationPanel.querySelector('.vt-translated');
    
    originalEl.textContent = text;
    translatedEl.textContent = '翻译中...';

    // 检测语言
    const isChinese = /[\u4e00-\u9fa5]/.test(text);
    const sourceLang = isChinese ? 'zh-CN' : 'en-US';
    const targetLang = isChinese ? 'en-US' : 'zh-CN';

    // 朗读原文
    speakImmediate(text, sourceLang);

    // 翻译
    const translated = await translateText(text, sourceLang, targetLang);
    
    if (translated && isEnabled) {
      translatedEl.textContent = translated;
      speakImmediate(translated, targetLang);
    }
  }

  // 翻译函数
  async function translateText(text, sourceLang, targetLang) {
    const sl = sourceLang.split('-')[0];
    const tl = targetLang.split('-')[0];

    // 方法1: Google翻译
    try {
      const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${sl}&tl=${tl}&dt=t&q=${encodeURIComponent(text)}`;
      const res = await fetch(url);
      const data = await res.json();
      if (data && data[0]) {
        return data[0].map(p => p[0]).join('');
      }
    } catch (e) { console.log('Google翻译失败'); }

    // 方法2: MyMemory
    try {
      const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${sl}|${tl}`;
      const res = await fetch(url);
      const data = await res.json();
      if (data && data.responseData) {
        return data.responseData.translatedText;
      }
    } catch (e) { console.log('MyMemory翻译失败'); }

    return '';
  }

  // 语音朗读
  function speakImmediate(text, lang) {
    if (!text || !isEnabled) return;

    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = lang;
    utterance.rate = currentRate;
    utterance.pitch = 1;

    const voices = window.speechSynthesis.getVoices();
    const voice = voices.find(v => v.lang.includes(lang.split('-')[0]));
    if (voice) utterance.voice = voice;

    window.speechSynthesis.speak(utterance);
  }

  // 开始监听字幕
  function startTranslator() {
    if (isEnabled) return;
    isEnabled = true;
    lastSubtitle = '';

    createPanel();

    const selector = getSubtitleSelector();
    let lastText = '';
    
    // 清理旧定时器
    if (checkInterval) clearInterval(checkInterval);
    
    checkInterval = setInterval(() => {
      if (!isEnabled) {
        clearInterval(checkInterval);
        return;
      }
      
      const subtitleEl = document.querySelector(selector);
      if (subtitleEl) {
        const text = subtitleEl.textContent.trim();
        if (text && text !== lastText) {
          lastText = text;
          translateAndSpeak(text);
        }
      }
    }, 300);

    console.log('🎙️ 视频双语朗读已启动 - 平台:', platform);
  }

  // 停止
  function stopTranslator() {
    isEnabled = false;
    if (checkInterval) {
      clearInterval(checkInterval);
      checkInterval = null;
    }
    window.speechSynthesis.cancel();
    if (translationPanel) {
      translationPanel.remove();
      translationPanel = null;
    }
    console.log('🛑 视频双语朗读已停止');
  }

  // 切换播放/暂停
  function togglePlayback() {
    isEnabled = !isEnabled;
    const btn = document.getElementById('vt-toggle');
    btn.textContent = isEnabled ? '⏸️ 暂停' : '▶️ 继续';
    if (!isEnabled) {
      window.speechSynthesis.cancel();
    }
  }

  // 监听popup消息
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'start') {
      startTranslator();
      sendResponse({ status: 'started', platform });
    } else if (request.action === 'stop') {
      stopTranslator();
      sendResponse({ status: 'stopped' });
    } else if (request.action === 'getStatus') {
      sendResponse({ isEnabled, platform });
    }
    return true;
  });

  // 预加载语音
  if (window.speechSynthesis) {
    window.speechSynthesis.getVoices();
    window.speechSynthesis.onvoiceschanged = () => {
      window.speechSynthesis.getVoices();
    };
  }

})();