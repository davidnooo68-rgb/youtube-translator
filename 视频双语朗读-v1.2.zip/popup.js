// popup.js - 插件弹窗控制 (v1.2 多平台版)

document.addEventListener('DOMContentLoaded', async () => {
  const toggleBtn = document.getElementById('toggle-btn');
  const stopBtn = document.getElementById('stop-btn');
  const statusDot = document.getElementById('status-dot');
  const statusText = document.getElementById('status-text');

  // 支持的平台
  const supportedPlatforms = ['youtube.com', 'bilibili.com', 'iqiyi.com', 'douyin.com', 'zhihu.com'];

  // 获取当前状态
  async function getStatus() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return;

    try {
      const response = await chrome.tabs.sendMessage(tab.id, { action: 'getStatus' });
      updateUI(response.isEnabled);
    } catch (e) {
      updateUI(false);
    }
  }

  // 更新UI状态
  function updateUI(isEnabled) {
    if (isEnabled) {
      statusDot.classList.add('active');
      statusText.textContent = '运行中';
      toggleBtn.classList.add('hidden');
      stopBtn.classList.remove('hidden');
    } else {
      statusDot.classList.remove('active');
      statusText.textContent = '未启动';
      toggleBtn.classList.remove('hidden');
      stopBtn.classList.add('hidden');
    }
  }

  // 检查是否支持当前页面
  function isSupportedPage(url) {
    return supportedPlatforms.some(p => url.includes(p));
  }

  // 开始朗读
  toggleBtn.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) {
      alert('请先打开视频页面');
      return;
    }

    if (!isSupportedPage(tab.url)) {
      alert('当前页面暂不支持，请打开 YouTube / B站 / 爱奇艺 / 抖音 / 知乎 的视频页面');
      return;
    }

    try {
      await chrome.tabs.sendMessage(tab.id, { action: 'start' });
      updateUI(true);
    } catch (e) {
      alert('无法连接到页面，请刷新后重试');
    }
  });

  // 停止朗读
  stopBtn.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return;

    try {
      await chrome.tabs.sendMessage(tab.id, { action: 'stop' });
      updateUI(false);
    } catch (e) {
      console.error('停止失败:', e);
    }
  });

  // 初始化
  getStatus();
});